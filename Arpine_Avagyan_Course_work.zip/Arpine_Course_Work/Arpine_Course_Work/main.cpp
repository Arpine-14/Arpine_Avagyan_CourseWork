#include "pch.h"
#include "maxMatching.h"
#include <iostream>

int main()
{
	Graph G(8);

	G.addNeighbor(0, 1);
	G.addNeighbor(0, 2);
	G.addNeighbor(0, 4);

	G.addNeighbor(1, 0);
	G.addNeighbor(1, 2);
	G.addNeighbor(1, 3);

	G.addNeighbor(2, 0);
	G.addNeighbor(2, 1);
	G.addNeighbor(2, 3);
	G.addNeighbor(2, 4);

	G.addNeighbor(3, 1);
	G.addNeighbor(3, 2);
	G.addNeighbor(3, 4);
	G.addNeighbor(3, 5);
	G.addNeighbor(3, 6);

	G.addNeighbor(4, 0);
	G.addNeighbor(4, 2);
	G.addNeighbor(4, 3);
	G.addNeighbor(4, 6);

	G.addNeighbor(5, 3);
	G.addNeighbor(5, 6);

	G.addNeighbor(6, 3);
	G.addNeighbor(6, 4);
	G.addNeighbor(6, 5);
	G.addNeighbor(6, 7);

	G.addNeighbor(7, 6);

	G.printAdjacencyList();

	G.findEdges();

	G.printEdges();

	std::cout << "\n\n The number of maximum matching is: " << G.findMaxMatching() << '\n';

	return 0;
}



