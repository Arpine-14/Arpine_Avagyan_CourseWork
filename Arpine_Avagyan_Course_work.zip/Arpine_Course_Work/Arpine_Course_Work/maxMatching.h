#pragma once
#include <vector>

class Graph
{
private:
	int number_of_vertices;
	std::vector<std::vector<int>> adjacency_list;
	std::vector<std::pair<int, int>> Edges;
public:
	Graph(int);
	void addNeighbor(int, int);
	void printAdjacencyList();
	void findEdges();
	void printEdges();
	int findMaxMatching();
};
