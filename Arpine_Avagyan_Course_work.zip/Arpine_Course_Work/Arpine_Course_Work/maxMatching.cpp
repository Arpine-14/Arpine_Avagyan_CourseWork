#include "pch.h"
#include "maxMatching.h"
#include <iostream>

Graph::Graph(int number)
{
	number_of_vertices = number;
	adjacency_list.resize(number);
}

void Graph::addNeighbor(int vertex_1, int vertex_2)
{
	adjacency_list[vertex_1].push_back(vertex_2);
}

void Graph::printAdjacencyList()
{
	std::cout << " *** Adjacency List ***\n";
	for (int i = 0; i < adjacency_list.size(); ++i)
	{
		std::cout << "\n " << i << ":";
		for (int j = 0; j < adjacency_list[i].size(); ++j)
		{
			std::cout << "  " << adjacency_list[i][j];
		}
	}
	std::cout << '\n';
}

void Graph::findEdges()
{
	for (int i = 0; i < adjacency_list.size(); ++i)
	{
		for (int j = 0; j < adjacency_list[i].size(); ++j)
		{
			if (adjacency_list[i][j] > i)
			{
				Edges.push_back(std::make_pair(i, adjacency_list[i][j]));
			}
		}
	}
}

void Graph::printEdges()
{
	std::cout << "\n Edges:";
	for (auto i = Edges.begin(); i != Edges.end(); ++i)
	{
		std::cout << "  {" << (*i).first << "," << (*i).second << "}";
	}
}

int Graph::findMaxMatching()
{
	std::vector<std::pair<int, int>> tmpEdgeList;
	std::vector<std::pair<int, int>> maxMatching;
	int q, a1, a2, b1, b2, max = 0;

	for (int i = 0; i < adjacency_list[0].size(); ++i)
	{
		std::cout << "\n\n i = " << i;
		tmpEdgeList = Edges;
		maxMatching.clear();
		maxMatching.push_back(std::make_pair(0, adjacency_list[0][i]));

		while (!tmpEdgeList.empty())
		{
			for (int j1 = 0; j1 < tmpEdgeList.size(); )
			{
				a1 = tmpEdgeList[j1].first;
				a2 = tmpEdgeList[j1].second;
				for (int j2 = 0; j2 < maxMatching.size(); ++j2)
				{
					b1 = maxMatching[j2].first;
					b2 = maxMatching[j2].second;
					if (a1 == b1 || a1 == b2 || a2 == b1 || a2 == b2)
					{
						if (j2 != 0)
						{
							if (j2 != maxMatching.size() - 1)
							{
								j1++;
								break;
							}
							j1++;
						}
						else
						{
							tmpEdgeList.erase(tmpEdgeList.begin() + j1);
							break;
						}
					}
					else if (j2 == maxMatching.size() - 1)
					{
						maxMatching.push_back(std::make_pair(a1, a2));
						tmpEdgeList.erase(tmpEdgeList.begin() + j1);
						break;
					}
				}
			}
			std::cout << "\n maxMatching:";
			for (int j = 0; j < maxMatching.size(); ++j)
			{
				std::cout << "  {" << maxMatching[j].first << "," << maxMatching[j].second << "}";
			}
			if (maxMatching.size() > max)
			{
				max = maxMatching.size();
			}
			maxMatching.erase(maxMatching.begin() + 1, maxMatching.end());
		}
	}
	return max;
}
